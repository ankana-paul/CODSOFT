const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');
let currentInput = '';
let firstOperand = null;
let operator = null;
let isSecondOperand = false;

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.textContent;

        if (button.classList.contains('number')) {
            handleNumber(value);
        } else if (button.classList.contains('operator')) {
            handleOperator(value);
        } else if (button.classList.contains('equals')) {
            handleEquals();
        } else if (button.classList.contains('clear')) {
            handleClear();
        }
    });
});

function handleNumber(number) {
    if (isSecondOperand) {
        currentInput = number;
        isSecondOperand = false;
    } else {
        currentInput += number;
    }
    display.textContent = currentInput;
}

function handleOperator(op) {
    if (firstOperand === null) {
        firstOperand = parseFloat(currentInput);
    } else if (operator) {
        firstOperand = performCalculation(firstOperand, parseFloat(currentInput), operator);
    }

    operator = op;
    isSecondOperand = true;
}

function handleEquals() {
    if (operator && !isSecondOperand) {
        currentInput = performCalculation(firstOperand, parseFloat(currentInput), operator);
        display.textContent = currentInput;
        firstOperand = null;
        operator = null;
    }
}

function handleClear() {
    currentInput = '';
    firstOperand = null;
    operator = null;
    display.textContent = '0';
}

function performCalculation(a, b, operator) {
    switch (operator) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            return a / b;
        default:
            return b;
    }
}